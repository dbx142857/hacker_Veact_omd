module.exports={
    foo:'bar'
}