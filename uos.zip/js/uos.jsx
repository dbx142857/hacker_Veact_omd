;(function(){
    let utils={
        insertRule:(function () {

            let strCache = [],
                maxIndex = -1;
            function getStyleSheet(unique_title) {
                let sheetLen=document.styleSheets.length
                for (var i = 0; i < sheetLen; i++) {
                    var sheet = document.styleSheets[i];
                    if (sheet.title == unique_title) {
                        return sheet;
                    }
                }
                if(!sheetLen){
                    let sheet=document.createElement('style');
                    document.head.appendChild(sheet);
                    return document.styleSheets[0]
                }
            }
    
            return function (str) {
                
                if (strCache.includes(str)) {
                    return
                }
                strCache.push(str)
                maxIndex++;
                let sheet = getStyleSheet()
                sheet.insertRule(str, maxIndex);
    
            }
    
        })(),
        guid() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
              var r = (Math.random() * 16) | 0,
                v = c == "x" ? r : (r & 0x3) | 0x8;
              return v.toString(16);
            });
          },handleEs6Template(strings, restArgs) {
              if(strings.length>1000){
                  throw '一个组件的模板里最多只允许使用1000个es6模板字符串定界符'
              }
            let res = ''
            for (let i = 0; i < 1000; i++) {
                res += (strings[i] || '') + (restArgs[i] || '')
                if (!strings[i] && !restArgs[i]) {
                    break;
                }
            }
            return res
        }
    }
    window.uos=function uos(classDefine){
        return new classDefine();
    }
    uos.load=uos;
    let allRegisteredComponents={}
    uos.getAllRegisteredComponents=()=>{
        return allRegisteredComponents
    }
    
    uos.use=(compClass)=>{
        if(!compClass.name){
            throw '组件必须拥有一个唯一的名字,才可以被注册为全局组件'
        }
        allRegisteredComponents[compClass.name]=compClass;
        return uos;
    }
    'html createGlobalStyle'.split(' ').forEach((k)=>{
        uos[k]=(strings, ...restArgs) =>utils.handleEs6Template(strings, restArgs)
    })
    uos.component=class{
        props(){ return {}}
        constructor($parent){
            this.$parent=$parent||null
            this.$refs={}
            this.uid='uos_comp_'+utils.guid()
            this.constructor;
            this.$options={
                name:this.constructor.name
            };
            [
                'styles',
                'beforeRender',
                'rendered',
                'props',
                'html',
            ].forEach((k)=>this.$options[k]=this[k]);
            setTimeout(()=>{
                this.$options.events=this.events
            })
            this._initStyle.call(this)
            this.props=this.props.call(this)
            this.$slots={}
        }
        beforeRender(){}
        rendered(){}
        _initStyle(){
            let styles = (function () {
                let styleStr=(this.$options.styles||function(){}).call(this)
                return !styleStr?'':styleStr.split('}').slice(0, -1).map((s) => s + '}');
            }).call(this);
            if (styles && styles.join('').trim() != '') {
                styles.forEach((sty) => {
                    if(sty.includes('&')){
                        sty = '.' + this.uid+' '+sty.replace(/\&/gi,'')
                    }else{
                        sty = '.' + this.uid+' '+sty
                    }
                    utils.insertRule(sty)
                })
            }
        }
        html(){return ''}
        _handleRefAndEvents(wrapper){
            for(let node of wrapper.querySelectorAll('*')){
                for (let attr of node.attributes) {
                    if(attr.nodeName=='ref'){
                        this.$refs[attr.value]=node
                    }else if(attr.nodeName.startsWith('@')){
                        node.addEventListener(attr.nodeName.substring(1),(e)=>{
                            if (/^[a-zA-Z\$_][a-zA-Z\d\$_]*$/.test(attr.value)) {
                                this.events[attr.value].call(this, e)
                            } else {
                                try {
                                    new Function(attr.value).call(this)
                                } catch (e) {
                                    console.warn('执行事件表达式:['+attr.value+']失败,错误信息为:');
                                    throw e;
                                }
                            }
                        })
                    }else if(attr.nodeName=='html' && node.nodeName.toUpperCase()=='SLOT'){
                        let htmlMethod=(attr.value)
                        if(!this[htmlMethod] && !uos.getAllRegisteredComponents()[htmlMethod]){
                            throw('组件不存在名称为'+htmlMethod+'的渲染方法,且uos全局组件中也不存在名称为'+htmlMethod+'的组件,渲染失败')
                        }
                        this.$slots[node.getAttribute('name')||'default']=node
                        node._uos_updateContent=()=>{
                            if(this[htmlMethod]){
                                node.innerHTML=this[htmlMethod]()
                            }else{
                                let $child=uos.load(uos.getAllRegisteredComponents()[htmlMethod])
                                $child.$parent=this;
                                $child.$renderTo(node)
    
                                if(!this.$children){
                                    this.$children=[]
                                }
                                this.$children.push($child)
                            }
                        }
                        if(node.getAttribute('lazy')==undefined){
                            node._uos_updateContent()
                        }
                    }
                }
            }
        }
        renderSlot(name){
            if(!name in this.$slots){
                throw '组件中不存在名称为'+name+'的插槽,更新内容失败'
            }
            this.$slots[name]._uos_updateContent()
        }
        async $renderTo(wrapper){
            await this.beforeRender.call(this)
            if(typeof(wrapper)=='string'){
                wrapper=document.querySelector(wrapper)
            }
            try{
                let htm=this.html();
                wrapper.innerHTML=htm;
                if(wrapper.childNodes.length!=1){
                    throw 'html声明必须包含有且只有一个根元素'
                }
                this.$el=wrapper.childNodes[0];
                this.$el.classList.add(this.uid)
                this._handleRefAndEvents(wrapper)
                setTimeout(()=>{
                    this.rendered.call(this)
                })
            }catch(e){
                console.warn('组件挂载失败,原因是:')
                throw e;
            }
        }
    }
})();







let {createGlobalStyle,html}=uos,
        
        compDefine=class demo1 extends uos.component{
            props(){
                return {
                    foo:'world',
                    bar:'this is a bar'
                }
            }
            test1(){
                return uos.html`<span><br><br>${this.props.bar}<br><br></span>`//lit-html
            }
            html(){
                return html`<div>
                    <span ref="redSpan" class="red">hello ${this.props.foo}
                    <br>
                    <button @click="handleBtnClick">i am a button</button>
    
                    <button ref="myBtn" @click="console.log(this.$refs)">打印$refs</button>
    
    <br>
    下面是一个懒加载的插槽
                    <slot lazy name="slot1" html="test1"></slot>
    
                    <button @click="this.renderSlot('slot1')">update slot content</button>
    
    <br>
    下面是一个立即加载的使用其他组件进行渲染的插槽:
                    <slot name="renderTest1" html="test1"></slot>
                </span>
                    </div>`
            }
            async beforeRender(){
                console.log('i am beforeRender',1)
                return new Promise((resolve)=>{
                    setTimeout(()=>{
    
                        this.props.foo='this world'
    
                
                        resolve();
                    },100);
                })
            }
            events={
                updateSlotContent(){
                    this.renderSlot('slot1')
                    
                },
                handleBtnClick(){
                    alert('123')
                }
            }
            rendered(){
                window.abc=this;
                console.log('i am rendered',2)
            }
            styles(){
                return createGlobalStyle`
                    &{
                        border:solid 1px green;

                        margin-top:200px;
                    }
                    &:hover{
                        /* border:solid 1px green; */
                        color:pink;
                    }
                    .red{
                        color:red;
                    }
                `
            }
        };
    
    
        uos.use(compDefine)
            .use(class test1 extends uos.component{
                rendered(){
                    window.test1=this
                }
                html(){
                    return `<span style="color:blue;"><br> i am a test1 comp instance,value 
                      of the key-foo of the $parent component is:<br> ${this.$parent.props.foo}</span>`
                }
            })
           .load(compDefine).$renderTo('#app');
        // uos(compDefine).$renderTo('#app');
    
    
    
    
            // features:
    
            // 允许在一段连续的代码块中同时对组件的结构,样式和行为进行定义
            // 包含beforeRender和rendered的生命周期机制
            // 可以使用es6模板字符串语法实现对模板的渲染
            // 支持scoped style
            // 支持通过ref快捷的访问目标元素
            // 支持在html中直接定义可以访问到组件js实例的事件声明或者事件表达式
            // 支持在渲染模板之前使用异步方法更改数据
            // 支持用于加载html代码片段的立即加载的插槽和懒加载的插槽

            // 支持用于加载子组件的插槽机制并建立父子关系

            // 1 为什么html=一个类就可以加载出来一个子组件
            // 2 html="test1",而test1和html代码不在一个作用域里,为何能访问的到----桥梁-全局组件机制
            //3 为什么html可以等于两种不同的东西/两种不同的东西优先级问题/


            // 1 一种组件加载机制
            // 2 父子组件的实现以及互相访问
            // 3 ref机制
            // 4 ref属于内置指令,那么支持多少个内置指令,内置指令的解析方式
            // 5 scoped style实现原理
            // 6 声明周期的原理

            // 流程:
                // 1 定义组件
                // 2 加载组件
                //     2.1 解析组件
                //         2.1.1解析指令
                //         2.1.3 解析事件
                //     2.2 实例化
                //     解析生命周期机制
                // 3 渲染组件:挂在组建到目标元素里



            // lazy->slot
            // html->slot
            // ref->任意元素
            // @xxx->事件->任意元素



            
            
    
            
    
            // 典型应用场景:
            // 在原生js项目里使用